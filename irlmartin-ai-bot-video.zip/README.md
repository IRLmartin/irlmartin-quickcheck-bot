# IRLmartin AI Bot (Video Auto-Scan Enabled)

## Features
- Slash commands: /quickcheck, /status, /healthcheck
- **Auto-Scan Video Uploads**: upload a video in ⛔-violations and the bot will:
  1. Extract audio
  2. Transcribe with Whisper (OpenAI Audio)
  3. Scan for risky phrases
  4. Reply with violations or "safe" message

## Deployment (Railway)
1. Push this repo to GitHub
2. Create a Railway project -> Deploy from GitHub
3. Add environment variables:
   - DISCORD_TOKEN
   - GUILD_ID
   - VIOLATIONS_CHANNEL_ID
   - STATUS_CHANNEL_ID
   - OWNER_ID
   - OPENAI_API_KEY
4. Deploy