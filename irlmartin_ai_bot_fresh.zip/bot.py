import os
import discord
from discord.ext import commands
from keep_alive import keep_alive

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix='/', intents=intents)

OWNER_ID = int(os.getenv("OWNER_ID", "0"))
GUILD_ID = int(os.getenv("GUILD_ID", "0"))
STATUS_CHANNEL_ID = int(os.getenv("STATUS_CHANNEL_ID", "0"))

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user} (ID: {bot.user.id})')

@bot.command()
async def status(ctx):
    if ctx.channel.id != STATUS_CHANNEL_ID:
        return
    cpu = "14.3%"  # placeholder
    memory = "49.0%"  # placeholder
    uptime = "2799252"  # placeholder
    await ctx.send(embed=discord.Embed(
        title="⚙️ Bot Status",
        description=f"**Logged in as**
{bot.user}

**CPU Usage**: {cpu}
**Memory Usage**: {memory}
**Uptime (secs)**: {uptime}

All systems nominal (no crashes)."
    ))

keep_alive()
bot.run(os.getenv("DISCORD_TOKEN"))