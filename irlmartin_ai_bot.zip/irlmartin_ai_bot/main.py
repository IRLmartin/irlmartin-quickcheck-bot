
import os
import discord
from discord import app_commands
from discord.ext import commands
import openai
import psutil
import asyncio
from aiohttp import web
import json

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
if not DISCORD_TOKEN:
    raise RuntimeError("Missing DISCORD_TOKEN environment variable.")

GUILD_ID = os.getenv("GUILD_ID", "")
OWNER_ID = os.getenv("OWNER_ID", "")
if not OWNER_ID:
    raise RuntimeError("Missing OWNER_ID environment variable.")

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
if not OPENAI_API_KEY:
    raise RuntimeError("Missing OPENAI_API_KEY environment variable.")

STATUS_CHANNEL_ID = os.getenv("STATUS_CHANNEL_ID", "")
if not STATUS_CHANNEL_ID:
    raise RuntimeError("Missing STATUS_CHANNEL_ID environment variable.")

openai.api_key = OPENAI_API_KEY

intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.members = True

class MyBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix="/", intents=intents)
        self.tree = app_commands.CommandTree(self)

    async def on_ready(self):
        print(f"✅ Logged in as {self.user} (ID {self.user.id})")
        if GUILD_ID:
            guild = discord.Object(id=int(GUILD_ID))
            synced = await self.tree.sync(guild=guild)
            print(f"✅ Synced {len(synced)} command(s) to guild {GUILD_ID}.")
        else:
            synced = await self.tree.sync()
            print(f"✅ Synced {len(synced)} global command(s).")

bot = MyBot()

def is_owner(interaction: discord.Interaction) -> bool:
    return str(interaction.user.id) == OWNER_ID

def owner_only():
    return app_commands.check(is_owner)

@bot.tree.command(name="status", description="Check bot health")
async def status(interaction: discord.Interaction):
    await interaction.response.defer(thinking=True)
    cpu_percent = psutil.cpu_percent(interval=1)
    virtual_mem = psutil.virtual_memory()
    mem_percent = virtual_mem.percent
    uptime_ts = int((discord.utils.utcnow().timestamp()) - psutil.boot_time())
    embed = discord.Embed(title="🤖 Bot Status", color=discord.Color.green())
    embed.add_field(name="Logged in as", value=f"{bot.user} (ID {bot.user.id})", inline=False)
    embed.add_field(name="CPU Usage", value=f"{cpu_percent:.1f}%")
    embed.add_field(name="Memory Usage", value=f"{mem_percent:.1f}%")
    embed.add_field(name="Uptime (secs)", value=str(uptime_ts))
    embed.set_footer(text="All systems nominal (no crashes).")
    await interaction.followup.send(embed=embed, ephemeral=True)

async def handle_health(request):
    return web.Response(text="OK", status=200)

async def start_health_server():
    app = web.Application()
    app.router.add_get("/", handle_health)
    app.router.add_get("/healthz", handle_health)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", 8080)
    await site.start()
    print("✅ Health server running on port 8080 (for Railway).")

async def main():
    await start_health_server()
    await bot.start(DISCORD_TOKEN)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
